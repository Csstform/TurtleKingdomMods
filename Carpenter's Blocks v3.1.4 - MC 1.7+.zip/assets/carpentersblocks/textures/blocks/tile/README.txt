********************************************************
*  	       HOW TO LOAD CUSTOM TILES                *
********************************************************

Tiles can be any icon file in .png format.  There is no
limit to how many may be loaded, and filename only
affects the sequential order of them in game.

To load your custom tiles, simply drag the icon files
into this folder, and they will be loaded automatically.